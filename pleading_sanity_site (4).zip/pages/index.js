export default function Home() {
  return (
    <div style={{textAlign: "center", paddingTop: "50px"}}>
      <h1>🧠 Rise From Madness</h1>
      <p>Welcome to Pleading Sanity. Your healing, your voice, your platform.</p>
    </div>
  );
}